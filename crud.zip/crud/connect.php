<?php
$servername = "localhost:3306";
$database_name = "db_sekolah";
$username_db = "root";
$password_db = "";

$conn = new mysqli($servername, $username_db, $password_db, $database_name);

if ($conn->connect_error) {
    die("Koneksi gagal : " . $conn->connect_error);
}
?>